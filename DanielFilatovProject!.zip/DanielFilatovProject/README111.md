Daniel Filatov– Portfolio Website

Hi and welcome 👋  
This is my portfolio site – a complete front-end project created as part of my Fullstack Web Development study. The goal was to build a responsive, well-designed website that showcases 8 unique projects using HTML, CSS, and JavaScript.


About the Project:

The site includes:
- A responsive homepage with a hero section, project gallery, contact form, and navigation
- 8 styled project pages
- Fully mobile-friendly
- java script functions
- images



Created by:
Daniel Filatov .

All the rights Reserved to Daniel Filatov
Thanks for visiting 🙏
