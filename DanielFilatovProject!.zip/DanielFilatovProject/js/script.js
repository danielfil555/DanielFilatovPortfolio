
window.addEventListener("load", () => {
    const loader = document.getElementById("loader");
    if (loader) {
        loader.style.display = "none";
    }
});


const hamburger = document.getElementById("hamburger");
const navLinks = document.getElementById("nav-links");

if (hamburger && navLinks) {
    hamburger.addEventListener("click", () => {
        navLinks.classList.toggle("show");
    });
}


document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute("href"));
        if (target) {
            target.scrollIntoView({ behavior: "smooth" });
        }

        if (window.innerWidth < 768) {
            navLinks.classList.remove("show");
        }
    });
});


function attachFormValidation(formId) {
    const form = document.getElementById(formId);
    if (form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();

            const inputs = form.querySelectorAll("input, textarea");
            let isValid = true;

            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                }
                if (input.type === "email") {
                    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!pattern.test(input.value.trim())) {
                        isValid = false;
                    }
                }
            });

            if (!isValid) {
                alert("Please fill out all fields correctly.");
                return;
            }

            alert("Thank you! Your message has been submitted.");
            form.reset();
        });
    }
}


attachFormValidation("contactForm");
attachFormValidation("newsletterForm");
attachFormValidation("consultForm");

document.getElementById("consultation-form").addEventListener("submit", function (e) {
    e.preventDefault();
    alert("Form submitted successfully!");
});


document.getElementById('consultationForm').addEventListener('submit', function (e) {
    e.preventDefault();
    alert("Thank you! We'll contact you soon.");
});
